# toan-lop7 – Quiz số hữu tỉ (LaTeX)

## Cách dùng (GitHub Pages)
1) Vào **Settings → Pages** → chọn Branch `main`, Folder `/ (root)` → **Save**.
2) Upload file **index.html** (file này) lên branch `main`.
3) Chờ 1–2 phút, link sẽ là: `https://<tài-khoản>.github.io/<tên-repo>/`.

## Cấu hình Webhook (tuỳ chọn)
Trong game bấm **Cài đặt** → dán `Webhook URL` (vd Apps Script Web App) và `Secret` (nếu dùng). Kết quả HS sẽ POST JSON về Google Sheets.

## Ghi chú
- Công thức LaTeX dùng `$$...$$` (MathJax CDN, cần Internet khi mở file).
- Thời gian: 2 phút/câu, tổng 40 phút.
